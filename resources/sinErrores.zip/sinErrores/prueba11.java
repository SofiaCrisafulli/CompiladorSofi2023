///c&3&exitosamente
class Init{
    static void main()
    {
        var a = 3;
        var b = 'c';
        System.printCln(b);
        debugPrint(a);

    }
}
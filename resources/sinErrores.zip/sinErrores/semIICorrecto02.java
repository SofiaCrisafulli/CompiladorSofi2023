///HELLO WORLD&exitosamente
class A {
     int a1;
    
     static void m1()
    {
        System.printS("HELLO WORLD");
    }

     void m2()
    {}
         
    

}



class Init{
    static void main()
    { A.m1();
    var v = 0;
    v = v +1;}
}

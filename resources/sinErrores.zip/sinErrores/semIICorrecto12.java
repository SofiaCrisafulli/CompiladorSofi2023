///0&exitosamente



class Init{
    static void main()
    {
        var b = 1;
        if(b<1){
            b = b + 1;
        }else
            b = b - 1;

        System.printI(b);

    }
}
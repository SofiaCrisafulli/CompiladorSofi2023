///HELLO WORLD&exitosamente
class Init{
    static void main()
    {
        System.printS("HELLO WORLD");
    }
}



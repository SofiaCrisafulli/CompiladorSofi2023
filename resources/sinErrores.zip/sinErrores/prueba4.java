///16&8&48&3&0&-8&true&false&true&false&true&false&true&false&c&true&hola&exitosamente
class Init{
    static void main(){
        debugPrint(12+4);
        System.println();
        System.printIln(12-4);
        debugPrint(12*4);
        System.println();
        System.printI(12/4);
        debugPrint(12%4);
        System.println();
        System.printIln(-12+4);
        System.printBln(true);
        System.printBln(12<4);
        System.printBln(12>4);
        System.printBln(12==4);
        System.printBln('c'!='d');
        System.printBln(true&&false);
        System.printBln(true||false);
        System.printBln(!true);
        System.printCln('c');
        System.printBln((12-8)==4);
        System.printS("hola");
        System.printSln("hola");
    }
}
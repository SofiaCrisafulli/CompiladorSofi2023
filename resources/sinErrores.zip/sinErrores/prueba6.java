///&exitosamente
class Init{
    static void main(){
        A.imprimir(0);
    }
}
class A {
    static void imprimir(int c) {
        while(c>0) {
            debugPrint(1234);
        }
    }
}
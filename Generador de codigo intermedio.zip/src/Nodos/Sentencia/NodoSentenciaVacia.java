package Nodos.Sentencia;

import AnalizadorSemantico.ExcepcionSemantica;

public class NodoSentenciaVacia extends NodoSentencia {

    @Override
    public void chequear() throws ExcepcionSemantica {

    }

    @Override
    public void generar() {

    }
}

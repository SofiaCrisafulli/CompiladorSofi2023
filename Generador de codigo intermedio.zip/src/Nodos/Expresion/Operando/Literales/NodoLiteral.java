package Nodos.Expresion.Operando.Literales;

import Nodos.Expresion.Operando.NodoOperando;
import TablaDeSimbolos.*;

public abstract class NodoLiteral extends NodoOperando {
}

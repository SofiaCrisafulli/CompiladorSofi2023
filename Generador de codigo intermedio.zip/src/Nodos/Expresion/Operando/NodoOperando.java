package Nodos.Expresion.Operando;

import Nodos.Expresion.NodoExpresionCompuesta;

public abstract class NodoOperando extends NodoExpresionCompuesta {

}
package TablaDeSimbolos;

public class TablaEstatica {
    static private TablaDeSimbolos tablaDeSimbolos;

    static public void startTabla() {
        tablaDeSimbolos = new TablaDeSimbolos();
    }
}

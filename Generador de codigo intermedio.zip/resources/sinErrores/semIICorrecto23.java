class Init {
    static void main() {
        var a = (2 * 6) + 2;
        System.printI(a);
    }
}




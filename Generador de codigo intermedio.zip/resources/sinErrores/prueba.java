///&exitosamente
class A{
    static void main(){}
    public A(){

    }
}
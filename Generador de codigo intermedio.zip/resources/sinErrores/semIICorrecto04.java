
class A {

    int m1(int a, int b){
        return a+b;
    }
    

}




class Init{
    static void main()
    {
        var v1 = new A();
        var c = v1.m1(3,6);
        System.printIln(c);
    }
}



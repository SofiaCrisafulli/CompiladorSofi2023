class A{

    static int m1(){
        return 912;
    }
}

class Init {
    static void main() {
        var a = new A();
        System.printI(a.m1());
    }
}




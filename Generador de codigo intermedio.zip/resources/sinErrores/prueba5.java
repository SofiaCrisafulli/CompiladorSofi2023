///12&exitosamente
class Init {
    static void main() {
        if(2<4){
            debugPrint(12);
        }else{
            debugPrint(4);
        }
        if((3<5) && true){

        }
    }
}
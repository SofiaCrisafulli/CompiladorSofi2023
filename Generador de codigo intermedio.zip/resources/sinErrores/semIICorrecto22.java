///10&exitosamente
class Init{
    static void main() {
        var a = 11;
            while (a != 0) {
                var b = 32;
                a = a - 1;
                System.printI(a);
            }

    }}




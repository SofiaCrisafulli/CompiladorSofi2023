



class Init{
    static void main()
    {
        var b = 1;
        if(b<1){
            b+=1;
        }else
            b-=1;

        System.printI(b);

    }
}
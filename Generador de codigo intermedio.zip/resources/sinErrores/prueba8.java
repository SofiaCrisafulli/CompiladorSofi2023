///1234&33&exitosamente

class Init{
    static void main()
    {
        mc(1234);
    }
    static void mc(int x){
        debugPrint(x);
        x = 33;
        debugPrint(x);
    }

}
///exitosamente
class A extends System {
    static void main(){
        var a = 1;
        var b = 2;
        var c = 3;
        debugPrint(a);
        println();
        debugPrint(b);
        println();
        debugPrint(c);
        println();
    }
}
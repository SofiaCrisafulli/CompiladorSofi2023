///1234&exitosamente


class Init{
    static void main()
    { 
        debugPrint(1234);
    }
}



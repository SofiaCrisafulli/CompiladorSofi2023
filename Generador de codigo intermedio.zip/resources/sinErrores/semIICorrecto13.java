



class Init{
    static void main()
    {
        var a=true;
        if(a){
            System.printI(1);
            System.printSln("texto + salto de linea");
            System.printS("texto");
            System.printCln('c');
            System.printC('e');
        }



    }
}
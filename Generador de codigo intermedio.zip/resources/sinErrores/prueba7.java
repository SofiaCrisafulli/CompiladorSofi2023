///&exitosamente
class Init{
    static void main(){
    }
}
class B {
    int c;
     void imprimir() {
        if(c>0) {
            debugPrint(1234);
        }
    }
}
class A extends B{
    int d;
    boolean igual(){
         if(d==c){
         }
    }
}
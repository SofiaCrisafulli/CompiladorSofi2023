class Init{
    static void main() {
        var a = 11;
            if (a != 0) {
                var b = 12;
                System.printI(a);
            }
            else
                System.printI(a);
        }
    }








class Init{
    static void main()
    {
        var b = 1;
        while (b<10){
            b+=1;
        }
        System.printI(b);

    }
}
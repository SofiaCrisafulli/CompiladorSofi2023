
class A {
    private int a1;
    
     void m1(){
         System.printS("HELLO WORLD");
    }

}



class Init{
    static void main()
    {
        var v = new A();
        v.m1();
    }
}


